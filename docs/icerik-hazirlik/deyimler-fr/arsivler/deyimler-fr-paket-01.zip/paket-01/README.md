# Fransızca deyimler — paket 01

14 kayıt, 28 örnek/çeviri ve 14 soru.

- [Asıl veri](fr-idioms-0001.json)
- [Kartlar ve cevaplar](INCELEME.md)
- [Cevapsız sorular](SORULAR.md)
- [Kaynaklar](KAYNAKLAR.md)
- [Kontrol](DOGRULAMA.json)
- [Devir notları](CLAUDE-DEVIR.md)

Antigravity raporu alındı; düzeltmelerin tekrar denetimi ve CEFR dağılımı bekliyor. Yeniden üretim araçları toplu 10 paket arşivindedir.
