# Fransızca deyimler — paket 02

26 kayıt, 52 örnek/çeviri ve 26 soru.

- [Asıl veri](fr-idioms-0002.json)
- [Kartlar ve cevaplar](INCELEME.md)
- [Cevapsız sorular](SORULAR.md)
- [Kaynaklar](KAYNAKLAR.md)
- [Kontrol](DOGRULAMA.json)
- [Devir notları](CLAUDE-DEVIR.md)

Bağımsız dil denetimi ve CEFR dağılımı bekliyor. Yeniden üretim araçları toplu 10 paket arşivindedir.
