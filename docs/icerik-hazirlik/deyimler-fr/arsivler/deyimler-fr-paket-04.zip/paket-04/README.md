# Fransızca deyimler — paket 04

25 kayıt, 50 örnek/çeviri ve 25 soru.

- [Asıl veri](fr-idioms-0004.json)
- [Kartlar ve cevaplar](INCELEME.md)
- [Cevapsız sorular](SORULAR.md)
- [Kaynaklar](KAYNAKLAR.md)
- [Kontrol](DOGRULAMA.json)
- [Devir notları](CLAUDE-DEVIR.md)

Antigravity raporu alındı; düzeltmelerin tekrar denetimi ve CEFR dağılımı bekliyor. Yeniden üretim araçları toplu 10 paket arşivindedir.
