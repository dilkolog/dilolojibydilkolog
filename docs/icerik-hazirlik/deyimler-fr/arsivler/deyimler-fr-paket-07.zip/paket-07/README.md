# Fransızca deyimler — paket 07

24 kayıt, 48 örnek/çeviri ve 24 soru.

- [Asıl veri](fr-idioms-0007.json)
- [Kartlar ve cevaplar](INCELEME.md)
- [Cevapsız sorular](SORULAR.md)
- [Kaynaklar](KAYNAKLAR.md)
- [Kontrol](DOGRULAMA.json)
- [Devir notları](CLAUDE-DEVIR.md)

Antigravity raporu alındı; düzeltmelerin tekrar denetimi ve CEFR dağılımı bekliyor. Yeniden üretim araçları toplu 10 paket arşivindedir.
