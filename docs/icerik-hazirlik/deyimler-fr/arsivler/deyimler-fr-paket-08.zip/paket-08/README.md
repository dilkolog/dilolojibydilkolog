# Fransızca deyimler — paket 08

21 kayıt, 42 örnek/çeviri ve 21 soru.

- [Asıl veri](fr-idioms-0008.json)
- [Kartlar ve cevaplar](INCELEME.md)
- [Cevapsız sorular](SORULAR.md)
- [Kaynaklar](KAYNAKLAR.md)
- [Kontrol](DOGRULAMA.json)
- [Devir notları](CLAUDE-DEVIR.md)

Antigravity raporu alındı; düzeltmelerin tekrar denetimi ve CEFR dağılımı bekliyor. Yeniden üretim araçları toplu 10 paket arşivindedir.
