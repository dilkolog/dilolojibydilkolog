# Claude için başlangıç

Bu arşiv proje klasör yollarını korur. [Tasarım devir dizinini oku](tasarim/CLAUDE-ONCE-OKU.md).
