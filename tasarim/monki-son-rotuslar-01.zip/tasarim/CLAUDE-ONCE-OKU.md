# Claude — önce bu dosyayı oku

Güncelleme: 10 Kasım 2026.

Bu klasör, kullanıcının tasarım çalışmalarıdır. Kullanıcı tasarım üretimini bu çalışmada yürüttü; uygulamaya aktarımı Claude ile yapmak istiyor. Her pakette `README.md`, `PAKET.json` ve ayrıntılı devir notu bulunur. Kullanıcı görselleri tek tek onaylatmadan üretme izni verdi; bu, bütün adayların otomatik olarak canlıya alınacağı anlamına gelmez. Önce güncel kod ile karşılaştırıp kullanıcının istediği tasarımları mevcut yapıya uygula.

## Çalışma durumu

- Çizimler, prototipler ve animasyonlar tasarım çıktısı olarak hazır.
- Çalışan `src/`, `api/` veya `worker/` uygulaması bu tasarım çalışmalarıyla değiştirilmedi; dağıtım yapılmadı.
- Çalışma alanında önceden var olan `src/engine/grammar.ts` ve `src/engine/__tests__/grammar.test.ts` değişiklikleri bu tasarım paketlerine ait değildir; üzerine yazma.
- Dosyalar bu çalışma ortamında yerel olarak duruyor. Commit/push yapılmadı. ZIP’ler ayrı taşınabilir kopyalardır.
- Bazı kaynaklar `docs/gelen-gorseller/` içinde; gitignore davranışı dosya ve alt klasöre göre değişir. Yalnızca `git status` çıktısını kaynak varlığının kanıtı sayma. İlgili ZIP’ler gereken kaynakları da içerir.

## Paket dizini

| Paket | İçerik | Önce okunacak dosya |
|---|---|---|
| `monki-01` | Yeni Monki pozları | [CLAUDE-DEVIR.md](monki-01/CLAUDE-DEVIR.md) |
| `ikonlar-01` | Arayüz ikon alternatifleri | [CLAUDE-DEVIR.md](ikonlar-01/CLAUDE-DEVIR.md) |
| `gorev-paketi-01` | Görev dosyasındaki 12 çizim | [CLAUDE-TESLIM.md](gorev-paketi-01/CLAUDE-TESLIM.md) |
| `monki-panel-01` | Monki sohbet paneli | [CLAUDE-DEVIR.md](monki-panel-01/CLAUDE-DEVIR.md) |
| `monki-denetim-01` | Monki görsel denetimi ve yenileme | [CLAUDE-DEVIR.md](monki-denetim-01/CLAUDE-DEVIR.md) |
| `monki-animasyon-01` | Monki el sallama animasyonu | [CLAUDE-DEVIR.md](monki-animasyon-01/CLAUDE-DEVIR.md) |
| `filiz-buyume-01` | Tohumdan çiçeğe büyüme | [CLAUDE-DEVIR.md](filiz-buyume-01/CLAUDE-DEVIR.md) |

## Birbiriyle ilişkili çalışmalar

- `monki-denetim-01` içindeki el sallama kaynağı statik bir ana karedir. Gerçek hareket denemesi sonraki `monki-animasyon-01` paketindedir.
- Sekizli animasyon önerisi listesinden filiz büyümesi ve küçük kutlama hazır. Diğer altı öneri tamamlanmadı. Ayrıca el sallama ve göz kırpma üretildi. En güncel göz kırpma/kutlama/el sallama adayları `monki-son-rotuslar-01` paketindedir.
- `filiz-buyume-01`, yeni bir öğrenme algoritması değildir. Mevcut -1 / 0–5 mastery aşamalarına görsel öneridir. Yalnızca doğru cevap sayısına bağlama.
- `gorev-paketi-01`, `docs/chatgpt/GORSEL-GOREVLERI.md` içindeki isimlendirmeyi korur. Güncel main’de aynı çizimlerin başka bir kaynakla işlenmiş olması mümkündür; kopyaları birbirinin üzerine körlemesine yazma.
- İncelemelerin bir bölümü main `bcf19328` üzerinden yapıldı; canlı dağıtım sürümü ayrıca doğrulanmadı. `monki-panel-01/mevcut-main.png` temsilî statik yeniden kurulumdur, canlı site ekran görüntüsü değildir.

## Ortak aktarım kuralları

AGENTS.md ve DESIGN.md geçerlidir. Mevcut tokenları, ikon sarmalayıcılarını ve bileşenleri kullan. Tasarım HTML’lerini doğrudan üretim ekranına çevirmeden önce mevcut işlevleri kontrol et. Prototip metinleri, örnek sohbet, kullanım değerleri ve demo düğmeleri gerçek veri veya iş kuralı değildir. Görsellerin hedef boyut, alfa kenarı, açık/koyu/sakin tema ve mobil davranışı entegrasyonda tekrar kontrol edilmeli. Animasyonların indirilebilir GIF/WebP sürümleri reduced-motion tercihini kendileri okuyamaz; uygulamada sabit poz seçilmeli.

## Dosya kimlikleri ve kaynaklar

`DOSYA-DIZINI.json`, paket klasöründeki dosyaların göreli yollarını, boyutlarını ve SHA-256 özetlerini listeler. Üretim hedefleri, ilgili `manifest.json`, `yeniden-tasarimlar.json`, `rig.json` veya ayrıntılı devir notundadır. Genel ad taşıyan bir katmanı (ör. `body.png`) klasöründen koparırken paket kimliğini dosya adına ekle; proje içi bağlantıları korumak için mevcut paket içi adlar değiştirilmedi.

## Son paket güncellemesi

`monki-son-rotuslar-01/CLAUDE-DEVIR.md`: kalan dinleme resmi ve iki animasyon yenilendi, el sallama omuz birleşimi v2 olarak tekrar kuruldu. İlgili eski paketleri silme; yeni sürüm eşleştirmesi PAKET.json içindedir.
